package com.devoteam.exceptions;

public class OutOfBoundsException extends Exception {
    public OutOfBoundsException(String errorMessage) {
        super(errorMessage);
    }
}
